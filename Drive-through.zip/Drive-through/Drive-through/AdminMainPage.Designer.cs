﻿namespace Drive_through
{
    partial class AdminMainPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminMainPage));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.BtnPbLogOut = new System.Windows.Forms.PictureBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.BtnPbSupport = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.BtnPbNotification = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.BtnPbBills = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.BtnPbDashboard = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.BtnPbHome = new System.Windows.Forms.PictureBox();
            this.panelChildForm = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbLogOut)).BeginInit();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbSupport)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbNotification)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbBills)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbDashboard)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbHome)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel7);
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(84, 591);
            this.panel1.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.BtnPbLogOut);
            this.panel7.Location = new System.Drawing.Point(16, 505);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(53, 52);
            this.panel7.TabIndex = 2;
            // 
            // BtnPbLogOut
            // 
            this.BtnPbLogOut.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbLogOut.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbLogOut.Image")));
            this.BtnPbLogOut.Location = new System.Drawing.Point(0, 0);
            this.BtnPbLogOut.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbLogOut.Name = "BtnPbLogOut";
            this.BtnPbLogOut.Size = new System.Drawing.Size(53, 52);
            this.BtnPbLogOut.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbLogOut.TabIndex = 0;
            this.BtnPbLogOut.TabStop = false;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.BtnPbSupport);
            this.panel6.Location = new System.Drawing.Point(16, 310);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(53, 52);
            this.panel6.TabIndex = 1;
            // 
            // BtnPbSupport
            // 
            this.BtnPbSupport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPbSupport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbSupport.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbSupport.Image")));
            this.BtnPbSupport.Location = new System.Drawing.Point(0, 0);
            this.BtnPbSupport.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbSupport.Name = "BtnPbSupport";
            this.BtnPbSupport.Size = new System.Drawing.Size(53, 52);
            this.BtnPbSupport.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbSupport.TabIndex = 4;
            this.BtnPbSupport.TabStop = false;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.BtnPbNotification);
            this.panel5.Location = new System.Drawing.Point(16, 245);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(53, 52);
            this.panel5.TabIndex = 1;
            // 
            // BtnPbNotification
            // 
            this.BtnPbNotification.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPbNotification.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbNotification.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbNotification.Image")));
            this.BtnPbNotification.Location = new System.Drawing.Point(0, 0);
            this.BtnPbNotification.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbNotification.Name = "BtnPbNotification";
            this.BtnPbNotification.Size = new System.Drawing.Size(53, 52);
            this.BtnPbNotification.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbNotification.TabIndex = 3;
            this.BtnPbNotification.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.BtnPbBills);
            this.panel4.Location = new System.Drawing.Point(16, 181);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(53, 52);
            this.panel4.TabIndex = 1;
            // 
            // BtnPbBills
            // 
            this.BtnPbBills.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPbBills.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbBills.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbBills.Image")));
            this.BtnPbBills.Location = new System.Drawing.Point(0, 0);
            this.BtnPbBills.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbBills.Name = "BtnPbBills";
            this.BtnPbBills.Size = new System.Drawing.Size(53, 52);
            this.BtnPbBills.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbBills.TabIndex = 2;
            this.BtnPbBills.TabStop = false;
            this.BtnPbBills.Click += new System.EventHandler(this.BtnPbBills_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.BtnPbDashboard);
            this.panel3.Location = new System.Drawing.Point(16, 117);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(53, 52);
            this.panel3.TabIndex = 1;
            // 
            // BtnPbDashboard
            // 
            this.BtnPbDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPbDashboard.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbDashboard.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbDashboard.Image")));
            this.BtnPbDashboard.Location = new System.Drawing.Point(0, 0);
            this.BtnPbDashboard.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbDashboard.Name = "BtnPbDashboard";
            this.BtnPbDashboard.Size = new System.Drawing.Size(53, 52);
            this.BtnPbDashboard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbDashboard.TabIndex = 1;
            this.BtnPbDashboard.TabStop = false;
            this.BtnPbDashboard.Click += new System.EventHandler(this.BtnPbDashboard_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.BtnPbHome);
            this.panel2.Location = new System.Drawing.Point(16, 52);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(53, 52);
            this.panel2.TabIndex = 0;
            // 
            // BtnPbHome
            // 
            this.BtnPbHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnPbHome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BtnPbHome.Image = ((System.Drawing.Image)(resources.GetObject("BtnPbHome.Image")));
            this.BtnPbHome.Location = new System.Drawing.Point(0, 0);
            this.BtnPbHome.Margin = new System.Windows.Forms.Padding(2);
            this.BtnPbHome.Name = "BtnPbHome";
            this.BtnPbHome.Size = new System.Drawing.Size(53, 52);
            this.BtnPbHome.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.BtnPbHome.TabIndex = 0;
            this.BtnPbHome.TabStop = false;
            this.BtnPbHome.Click += new System.EventHandler(this.BtnPbHome_Click);
            // 
            // panelChildForm
            // 
            this.panelChildForm.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panelChildForm.Location = new System.Drawing.Point(86, 0);
            this.panelChildForm.Margin = new System.Windows.Forms.Padding(2);
            this.panelChildForm.Name = "panelChildForm";
            this.panelChildForm.Size = new System.Drawing.Size(1029, 591);
            this.panelChildForm.TabIndex = 3;
            this.panelChildForm.Paint += new System.Windows.Forms.PaintEventHandler(this.panelChildForm_Paint);
            // 
            // AdminMainPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 591);
            this.Controls.Add(this.panelChildForm);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "AdminMainPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminMainPage";
            this.Load += new System.EventHandler(this.AdminMainPage_Load);
            this.panel1.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbLogOut)).EndInit();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbSupport)).EndInit();
            this.panel5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbNotification)).EndInit();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbBills)).EndInit();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbDashboard)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BtnPbHome)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panelChildForm;
        private System.Windows.Forms.PictureBox BtnPbHome;
        private System.Windows.Forms.PictureBox BtnPbSupport;
        private System.Windows.Forms.PictureBox BtnPbNotification;
        private System.Windows.Forms.PictureBox BtnPbBills;
        private System.Windows.Forms.PictureBox BtnPbDashboard;
        private System.Windows.Forms.PictureBox BtnPbLogOut;
    }
}