﻿namespace Drive_through
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderMenuItem14 = new Drive_through.OrderMenuItem();
            this.orderMenuItem13 = new Drive_through.OrderMenuItem();
            this.orderMenuItem12 = new Drive_through.OrderMenuItem();
            this.orderMenuItem11 = new Drive_through.OrderMenuItem();
            this.orderMenuItem10 = new Drive_through.OrderMenuItem();
            this.orderMenuItem9 = new Drive_through.OrderMenuItem();
            this.orderMenuItem8 = new Drive_through.OrderMenuItem();
            this.orderMenuItem7 = new Drive_through.OrderMenuItem();
            this.orderMenuItem6 = new Drive_through.OrderMenuItem();
            this.orderMenuItem5 = new Drive_through.OrderMenuItem();
            this.orderMenuItem4 = new Drive_through.OrderMenuItem();
            this.orderMenuItem3 = new Drive_through.OrderMenuItem();
            this.orderMenuItem2 = new Drive_through.OrderMenuItem();
            this.orderMenuItem1 = new Drive_through.OrderMenuItem();
            this.orderMenuItem15 = new Drive_through.OrderMenuItem();
            this.SuspendLayout();
            // 
            // orderMenuItem14
            // 
            this.orderMenuItem14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem14.Location = new System.Drawing.Point(216, 269);
            this.orderMenuItem14.Name = "orderMenuItem14";
            this.orderMenuItem14.OnDelClick = null;
            this.orderMenuItem14.OnEditClick = null;
            this.orderMenuItem14.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem14.TabIndex = 13;
            // 
            // orderMenuItem13
            // 
            this.orderMenuItem13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem13.Location = new System.Drawing.Point(216, 100);
            this.orderMenuItem13.Name = "orderMenuItem13";
            this.orderMenuItem13.OnDelClick = null;
            this.orderMenuItem13.OnEditClick = null;
            this.orderMenuItem13.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem13.TabIndex = 12;
            // 
            // orderMenuItem12
            // 
            this.orderMenuItem12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem12.Location = new System.Drawing.Point(216, 156);
            this.orderMenuItem12.Name = "orderMenuItem12";
            this.orderMenuItem12.OnDelClick = null;
            this.orderMenuItem12.OnEditClick = null;
            this.orderMenuItem12.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem12.TabIndex = 11;
            // 
            // orderMenuItem11
            // 
            this.orderMenuItem11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem11.Location = new System.Drawing.Point(216, 212);
            this.orderMenuItem11.Name = "orderMenuItem11";
            this.orderMenuItem11.OnDelClick = null;
            this.orderMenuItem11.OnEditClick = null;
            this.orderMenuItem11.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem11.TabIndex = 10;
            // 
            // orderMenuItem10
            // 
            this.orderMenuItem10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem10.Location = new System.Drawing.Point(216, 44);
            this.orderMenuItem10.Name = "orderMenuItem10";
            this.orderMenuItem10.OnDelClick = null;
            this.orderMenuItem10.OnEditClick = null;
            this.orderMenuItem10.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem10.TabIndex = 9;
            // 
            // orderMenuItem9
            // 
            this.orderMenuItem9.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem9.Location = new System.Drawing.Point(461, 29);
            this.orderMenuItem9.Name = "orderMenuItem9";
            this.orderMenuItem9.OnDelClick = null;
            this.orderMenuItem9.OnEditClick = null;
            this.orderMenuItem9.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem9.TabIndex = 8;
            // 
            // orderMenuItem8
            // 
            this.orderMenuItem8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem8.Location = new System.Drawing.Point(461, 197);
            this.orderMenuItem8.Name = "orderMenuItem8";
            this.orderMenuItem8.OnDelClick = null;
            this.orderMenuItem8.OnEditClick = null;
            this.orderMenuItem8.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem8.TabIndex = 7;
            // 
            // orderMenuItem7
            // 
            this.orderMenuItem7.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem7.Location = new System.Drawing.Point(461, 197);
            this.orderMenuItem7.Name = "orderMenuItem7";
            this.orderMenuItem7.OnDelClick = null;
            this.orderMenuItem7.OnEditClick = null;
            this.orderMenuItem7.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem7.TabIndex = 6;
            // 
            // orderMenuItem6
            // 
            this.orderMenuItem6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem6.Location = new System.Drawing.Point(461, 85);
            this.orderMenuItem6.Name = "orderMenuItem6";
            this.orderMenuItem6.OnDelClick = null;
            this.orderMenuItem6.OnEditClick = null;
            this.orderMenuItem6.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem6.TabIndex = 5;
            // 
            // orderMenuItem5
            // 
            this.orderMenuItem5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem5.Location = new System.Drawing.Point(461, 141);
            this.orderMenuItem5.Name = "orderMenuItem5";
            this.orderMenuItem5.OnDelClick = null;
            this.orderMenuItem5.OnEditClick = null;
            this.orderMenuItem5.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem5.TabIndex = 4;
            // 
            // orderMenuItem4
            // 
            this.orderMenuItem4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem4.Location = new System.Drawing.Point(461, 309);
            this.orderMenuItem4.Name = "orderMenuItem4";
            this.orderMenuItem4.OnDelClick = null;
            this.orderMenuItem4.OnEditClick = null;
            this.orderMenuItem4.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem4.TabIndex = 3;
            // 
            // orderMenuItem3
            // 
            this.orderMenuItem3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem3.Location = new System.Drawing.Point(461, 197);
            this.orderMenuItem3.Name = "orderMenuItem3";
            this.orderMenuItem3.OnDelClick = null;
            this.orderMenuItem3.OnEditClick = null;
            this.orderMenuItem3.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem3.TabIndex = 2;
            // 
            // orderMenuItem2
            // 
            this.orderMenuItem2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem2.Location = new System.Drawing.Point(461, 253);
            this.orderMenuItem2.Name = "orderMenuItem2";
            this.orderMenuItem2.OnDelClick = null;
            this.orderMenuItem2.OnEditClick = null;
            this.orderMenuItem2.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem2.TabIndex = 1;
            // 
            // orderMenuItem1
            // 
            this.orderMenuItem1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem1.Location = new System.Drawing.Point(461, 85);
            this.orderMenuItem1.Name = "orderMenuItem1";
            this.orderMenuItem1.OnDelClick = null;
            this.orderMenuItem1.OnEditClick = null;
            this.orderMenuItem1.Size = new System.Drawing.Size(222, 50);
            this.orderMenuItem1.TabIndex = 0;
            // 
            // orderMenuItem15
            // 
            this.orderMenuItem15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.orderMenuItem15.Location = new System.Drawing.Point(75, 43);
            this.orderMenuItem15.Name = "orderMenuItem15";
            this.orderMenuItem15.OnDelClick = null;
            this.orderMenuItem15.OnEditClick = null;
            this.orderMenuItem15.Size = new System.Drawing.Size(239, 50);
            this.orderMenuItem15.TabIndex = 14;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.orderMenuItem15);
            this.Controls.Add(this.orderMenuItem14);
            this.Controls.Add(this.orderMenuItem13);
            this.Controls.Add(this.orderMenuItem12);
            this.Controls.Add(this.orderMenuItem11);
            this.Controls.Add(this.orderMenuItem10);
            this.Controls.Add(this.orderMenuItem9);
            this.Controls.Add(this.orderMenuItem8);
            this.Controls.Add(this.orderMenuItem7);
            this.Controls.Add(this.orderMenuItem6);
            this.Controls.Add(this.orderMenuItem5);
            this.Controls.Add(this.orderMenuItem4);
            this.Controls.Add(this.orderMenuItem3);
            this.Controls.Add(this.orderMenuItem2);
            this.Controls.Add(this.orderMenuItem1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private OrderMenuItem orderMenuItem1;
        private OrderMenuItem orderMenuItem2;
        private OrderMenuItem orderMenuItem3;
        private OrderMenuItem orderMenuItem4;
        private OrderMenuItem orderMenuItem5;
        private OrderMenuItem orderMenuItem6;
        private OrderMenuItem orderMenuItem7;
        private OrderMenuItem orderMenuItem8;
        private OrderMenuItem orderMenuItem9;
        private OrderMenuItem orderMenuItem10;
        private OrderMenuItem orderMenuItem11;
        private OrderMenuItem orderMenuItem12;
        private OrderMenuItem orderMenuItem13;
        private OrderMenuItem orderMenuItem14;
        private OrderMenuItem orderMenuItem15;
    }
}

