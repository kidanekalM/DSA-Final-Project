﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Drive_through.domain
{
    public class HomeEvents
    {
        //public EventHandler MenuCatagoryClick { get; set; }
        public HomeEvents( ) 
        {

        }
        public void MenuCatagoryClicked(Object sender, EventArgs e) 
        {
            
        }
        public void FoodClicked(Object sender, EventArgs e)
        {

        }
        public void SearchTextChange(Object sender, EventArgs e)
        {

        }
        public void OrderMenuEditClick(Object sender, EventArgs e)
        {

        }
        public void OrderMenuDeleteClick(Object sender, EventArgs e)
        {

        }
        public void ChargePriceClick(Object sender, EventArgs e)
        {

        }
    }
}
